#!/usr/bin/env python3

# Created by Gabriel A
# Created on Dec 2020
# This program generates a number and asks to guess which number


import random


def main():
    # input
    guessed = int(input("Pick a number between 0-9: "))
    value = random.randint(0, 9)

    # process
    if guessed == value:
        # output
        print("Congratulations! You picked the right number!")

    if guessed != value:
        print("Wrong number! Try again.")


if __name__ == "__main__":
    main()
